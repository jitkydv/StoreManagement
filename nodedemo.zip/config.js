const config = {
  db: {
    host: "localhost",
    user: "root",
    password: "",
    database: "nodetest",
  },
};

module.exports = config;
